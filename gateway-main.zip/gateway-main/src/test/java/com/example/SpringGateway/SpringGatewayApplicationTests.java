package com.example.SpringGateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
